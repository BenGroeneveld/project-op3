Connector/Net 6.9  Release Notes
------------------------------------

Welcome to the release notes for Connector/Net 6.9

What's new in 6.9
--------------------

- Simple Membership Web Provider
- Site Map Web Provider
- Personalization Web Provider
- MySql Fabric support


Be sure and check the documentation for more information on these new features.