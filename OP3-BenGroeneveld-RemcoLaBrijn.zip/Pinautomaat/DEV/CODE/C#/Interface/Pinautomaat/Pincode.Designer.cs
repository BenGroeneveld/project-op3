﻿namespace Pinautomaat
{
    partial class Pincode
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if(disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.btnCorrectie = new System.Windows.Forms.Button();
            this.txtCardID = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.inputInloggen = new System.Windows.Forms.TextBox();
            this.btnVolgende = new System.Windows.Forms.Button();
            this.btnUitloggen = new System.Windows.Forms.Button();
            this.infoText = new System.Windows.Forms.Label();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 11;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 9.091001F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 9.091001F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 9.091001F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 9.091001F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 9.091001F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 9.091001F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 9.091001F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 9.091001F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 9.091001F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 9.090091F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 9.090909F));
            this.tableLayoutPanel1.Controls.Add(this.btnCorrectie, 2, 6);
            this.tableLayoutPanel1.Controls.Add(this.txtCardID, 9, 0);
            this.tableLayoutPanel1.Controls.Add(this.textBox3, 8, 3);
            this.tableLayoutPanel1.Controls.Add(this.textBox2, 6, 3);
            this.tableLayoutPanel1.Controls.Add(this.textBox1, 4, 3);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.inputInloggen, 2, 3);
            this.tableLayoutPanel1.Controls.Add(this.btnVolgende, 6, 9);
            this.tableLayoutPanel1.Controls.Add(this.btnUitloggen, 2, 9);
            this.tableLayoutPanel1.Controls.Add(this.infoText, 2, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 12;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333417F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333417F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333417F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.133333F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.4F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333417F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333417F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333417F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333417F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.332583F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 28F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1916, 1053);
            this.tableLayoutPanel1.TabIndex = 2;
            // 
            // btnCorrectie
            // 
            this.btnCorrectie.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.tableLayoutPanel1.SetColumnSpan(this.btnCorrectie, 3);
            this.btnCorrectie.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCorrectie.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnCorrectie.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnCorrectie.FlatAppearance.BorderSize = 0;
            this.btnCorrectie.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCorrectie.Font = new System.Drawing.Font("Open Sans", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCorrectie.ForeColor = System.Drawing.Color.White;
            this.btnCorrectie.Location = new System.Drawing.Point(348, 521);
            this.btnCorrectie.Margin = new System.Windows.Forms.Padding(0);
            this.btnCorrectie.Name = "btnCorrectie";
            this.tableLayoutPanel1.SetRowSpan(this.btnCorrectie, 2);
            this.btnCorrectie.Size = new System.Drawing.Size(522, 174);
            this.btnCorrectie.TabIndex = 21;
            this.btnCorrectie.Text = "[A] Corrigeer pincode";
            this.btnCorrectie.UseVisualStyleBackColor = false;
            this.btnCorrectie.Click += new System.EventHandler(this.btnCorrectie_Click);
            // 
            // txtCardID
            // 
            this.txtCardID.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
            this.tableLayoutPanel1.SetColumnSpan(this.txtCardID, 2);
            this.txtCardID.Cursor = System.Windows.Forms.Cursors.Default;
            this.txtCardID.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtCardID.Font = new System.Drawing.Font("Open Sans", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCardID.ForeColor = System.Drawing.Color.White;
            this.txtCardID.Location = new System.Drawing.Point(1566, 0);
            this.txtCardID.Margin = new System.Windows.Forms.Padding(0);
            this.txtCardID.Name = "txtCardID";
            this.tableLayoutPanel1.SetRowSpan(this.txtCardID, 2);
            this.txtCardID.Size = new System.Drawing.Size(350, 174);
            this.txtCardID.TabIndex = 17;
            this.txtCardID.Text = "cardID";
            this.txtCardID.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // textBox3
            // 
            this.textBox3.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox3.Cursor = System.Windows.Forms.Cursors.Default;
            this.textBox3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 119F, System.Drawing.FontStyle.Bold);
            this.textBox3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
            this.textBox3.Location = new System.Drawing.Point(1392, 261);
            this.textBox3.Margin = new System.Windows.Forms.Padding(0);
            this.textBox3.MaxLength = 1;
            this.textBox3.Name = "textBox3";
            this.textBox3.ReadOnly = true;
            this.textBox3.Size = new System.Drawing.Size(174, 180);
            this.textBox3.TabIndex = 16;
            this.textBox3.TabStop = false;
            this.textBox3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox3.UseSystemPasswordChar = true;
            this.textBox3.TextChanged += new System.EventHandler(this.textBox3_TextChanged);
            // 
            // textBox2
            // 
            this.textBox2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox2.Cursor = System.Windows.Forms.Cursors.Default;
            this.textBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 119F, System.Drawing.FontStyle.Bold);
            this.textBox2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
            this.textBox2.Location = new System.Drawing.Point(1044, 261);
            this.textBox2.Margin = new System.Windows.Forms.Padding(0);
            this.textBox2.MaxLength = 1;
            this.textBox2.Name = "textBox2";
            this.textBox2.ReadOnly = true;
            this.textBox2.Size = new System.Drawing.Size(174, 180);
            this.textBox2.TabIndex = 15;
            this.textBox2.TabStop = false;
            this.textBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox2.UseSystemPasswordChar = true;
            this.textBox2.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // textBox1
            // 
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox1.Cursor = System.Windows.Forms.Cursors.Default;
            this.textBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 119F, System.Drawing.FontStyle.Bold);
            this.textBox1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
            this.textBox1.Location = new System.Drawing.Point(696, 261);
            this.textBox1.Margin = new System.Windows.Forms.Padding(0);
            this.textBox1.MaxLength = 1;
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(174, 180);
            this.textBox1.TabIndex = 14;
            this.textBox1.TabStop = false;
            this.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox1.UseSystemPasswordChar = true;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // pictureBox1
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.pictureBox1, 2);
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox1.Image = global::Pinautomaat.Properties.Resources.Logo;
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox1.Name = "pictureBox1";
            this.tableLayoutPanel1.SetRowSpan(this.pictureBox1, 2);
            this.pictureBox1.Size = new System.Drawing.Size(348, 174);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 13;
            this.pictureBox1.TabStop = false;
            // 
            // inputInloggen
            // 
            this.inputInloggen.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.inputInloggen.Cursor = System.Windows.Forms.Cursors.Default;
            this.inputInloggen.Dock = System.Windows.Forms.DockStyle.Fill;
            this.inputInloggen.Font = new System.Drawing.Font("Microsoft Sans Serif", 119F, System.Drawing.FontStyle.Bold);
            this.inputInloggen.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
            this.inputInloggen.Location = new System.Drawing.Point(348, 261);
            this.inputInloggen.Margin = new System.Windows.Forms.Padding(0);
            this.inputInloggen.MaxLength = 1;
            this.inputInloggen.Name = "inputInloggen";
            this.inputInloggen.ReadOnly = true;
            this.inputInloggen.Size = new System.Drawing.Size(174, 180);
            this.inputInloggen.TabIndex = 12;
            this.inputInloggen.TabStop = false;
            this.inputInloggen.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.inputInloggen.UseSystemPasswordChar = true;
            this.inputInloggen.TextChanged += new System.EventHandler(this.inputInloggen_TextChanged);
            // 
            // btnVolgende
            // 
            this.btnVolgende.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.tableLayoutPanel1.SetColumnSpan(this.btnVolgende, 3);
            this.btnVolgende.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnVolgende.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnVolgende.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnVolgende.FlatAppearance.BorderSize = 0;
            this.btnVolgende.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnVolgende.Font = new System.Drawing.Font("Open Sans", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVolgende.ForeColor = System.Drawing.Color.White;
            this.btnVolgende.Location = new System.Drawing.Point(1044, 782);
            this.btnVolgende.Margin = new System.Windows.Forms.Padding(0);
            this.btnVolgende.Name = "btnVolgende";
            this.tableLayoutPanel1.SetRowSpan(this.btnVolgende, 2);
            this.btnVolgende.Size = new System.Drawing.Size(522, 174);
            this.btnVolgende.TabIndex = 10;
            this.btnVolgende.Text = "[D] OK";
            this.btnVolgende.UseVisualStyleBackColor = false;
            this.btnVolgende.Click += new System.EventHandler(this.btnVolgende_Click);
            // 
            // btnUitloggen
            // 
            this.btnUitloggen.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.tableLayoutPanel1.SetColumnSpan(this.btnUitloggen, 3);
            this.btnUitloggen.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnUitloggen.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnUitloggen.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnUitloggen.FlatAppearance.BorderSize = 0;
            this.btnUitloggen.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnUitloggen.Font = new System.Drawing.Font("Open Sans", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUitloggen.ForeColor = System.Drawing.Color.White;
            this.btnUitloggen.Location = new System.Drawing.Point(348, 782);
            this.btnUitloggen.Margin = new System.Windows.Forms.Padding(0);
            this.btnUitloggen.Name = "btnUitloggen";
            this.tableLayoutPanel1.SetRowSpan(this.btnUitloggen, 2);
            this.btnUitloggen.Size = new System.Drawing.Size(522, 174);
            this.btnUitloggen.TabIndex = 9;
            this.btnUitloggen.Text = "[C] Stoppen";
            this.btnUitloggen.UseVisualStyleBackColor = false;
            this.btnUitloggen.Click += new System.EventHandler(this.btnUitloggen_Click);
            // 
            // infoText
            // 
            this.infoText.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
            this.tableLayoutPanel1.SetColumnSpan(this.infoText, 7);
            this.infoText.Cursor = System.Windows.Forms.Cursors.Default;
            this.infoText.Dock = System.Windows.Forms.DockStyle.Fill;
            this.infoText.Font = new System.Drawing.Font("Open Sans", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.infoText.ForeColor = System.Drawing.Color.White;
            this.infoText.Location = new System.Drawing.Point(348, 0);
            this.infoText.Margin = new System.Windows.Forms.Padding(0);
            this.infoText.Name = "infoText";
            this.tableLayoutPanel1.SetRowSpan(this.infoText, 2);
            this.infoText.Size = new System.Drawing.Size(1218, 174);
            this.infoText.TabIndex = 4;
            this.infoText.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Pincode
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
            this.ClientSize = new System.Drawing.Size(1916, 1053);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Font = new System.Drawing.Font("Open Sans", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "Pincode";
            this.Text = "Pincode";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Shown += new System.EventHandler(this.Pincode_Shown);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label infoText;
        private System.Windows.Forms.Button btnUitloggen;
        private System.Windows.Forms.Button btnVolgende;
        private System.Windows.Forms.TextBox inputInloggen;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label txtCardID;
        private System.Windows.Forms.Button btnCorrectie;
    }
}